# Copyright 2025 the LlamaFactory team.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.


from dataclasses import dataclass, field

from .arg_utils import SampleBackend


@dataclass
class SampleArguments:
    sample_backend: SampleBackend = field(
        default=SampleBackend.HF,
        metadata={"help": "Sampling backend, default to 'hf'."},
    )
    max_new_tokens: int = field(
        default=128,
        metadata={"help": "Maximum number of new tokens to generate."},
    )
